def perform_calculation(input_equation):
	return str(eval(input_equation))