void a_function(char *message);
